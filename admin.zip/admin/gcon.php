<?php
$server = "localhost";
$user  = "ankitmat_geneses";
$pwd = "ankit@1010";
$dbname = "ankitmat_database";
$con = mysqli_connect($server,$user,$pwd,$dbname);
if(!$con){
	echo "Database Not connected";
}
 
?>